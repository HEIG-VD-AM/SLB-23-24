#!/bin/bash

# Trier le fichier et extraire la première ligne pour la valeur minimale
min_hex=$(sort chall4_aslr-sample.txt | head -n 1)

# Trier le fichier en ordre inverse et extraire la première ligne pour la valeur maximale
max_hex=$(sort -r chall4_aslr-sample.txt | head -n 1)

# Afficher les résultats
echo "Valeur minimale: $min_hex"
echo "Valeur maximale: $max_hex"
