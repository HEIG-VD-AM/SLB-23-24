from struct import *

address = 0x00
count = 0
with open("chall4_aslr-sample.txt") as f:
	for line in f:
		count+=1
		address+=int(line,16)


print(hex(address//count))
