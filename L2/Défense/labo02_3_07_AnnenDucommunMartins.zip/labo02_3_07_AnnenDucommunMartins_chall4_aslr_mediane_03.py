def median(numbers):
    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)
    middle = n // 2
    if n % 2 == 0:
        return (sorted_numbers[middle - 1] + sorted_numbers[middle]) / 2
    else:
        return sorted_numbers[middle]

hex_numbers = []
with open("chall4_aslr-sample.txt") as f:
    for line in f:
        hex_numbers.append(int(line.strip(), 16))

median_value = median(hex_numbers)
print(hex(int(median_value)))

